## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup---------------------------------------------------------------
library(LDFA)

## ------------------------------------------------------------------------
x<- Partition(iris) # This function partitions your dataset into test and training subsets at a ratio of 20% to 80% as the default. You should store this in a separate variable which will keep two lists associated witht the test and training data.

## ------------------------------------------------------------------------
y <- DFA_pred(Species~., x$train) # This function takes a specified model (your groups ~ predictor variables) and then uses that model to predict group membership of you specified data. In this case we have specified the training data.
z <- DFA_pred(Species~., x$test)

## ------------------------------------------------------------------------
DFA_plot(y)
g <- DFA_plot(y) # This function takes the prediction data derived from the DFA_pred function and plots it using ggplot.
g

## ------------------------------------------------------------------------
Accuracy(z, x$test$Species)
# This function takes your predicted group assignments of the training and test data and compares it to the actual group assignments. It then takes the mean to show the porpotion correct for each dataset. 

